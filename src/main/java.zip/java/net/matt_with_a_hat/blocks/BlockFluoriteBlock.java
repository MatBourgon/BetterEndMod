package net.matt_with_a_hat.blocks;

import net.minecraft.block.Block;

public class BlockFluoriteBlock extends Block {
    
    public BlockFluoriteBlock(Settings settings)
    {
        super(settings);
    }
}
