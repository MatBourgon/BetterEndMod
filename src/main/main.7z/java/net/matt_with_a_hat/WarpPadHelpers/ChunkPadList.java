package net.matt_with_a_hat.WarpPadHelpers;

import java.util.ArrayList;
import java.util.List;

import org.jetbrains.annotations.Nullable;

import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import software.bernie.shadowed.eliotlash.mclib.math.functions.classic.Cos;

public class ChunkPadList
{
    List<BlockPos> warps;
    int chunkX, chunkZ;

    public ChunkPadList(int chunkX, int chunkZ)
    {
        this.chunkX = chunkX;
        this.chunkZ = chunkZ;
        warps = new ArrayList<BlockPos>();
    }

    public int getX() {return chunkX;}
    public int getZ() {return chunkZ;}

    public boolean isWarpInList(BlockPos pad)
    {
        return warps.contains(pad);
    }

    public void add(BlockPos warp)
    {
        if (!isWarpInList(warp))
            warps.add(warp);

    }

    public void remove(BlockPos warp)
    {
        warps.remove(warp);
    }

    @Nullable
    public BlockPos findNearestBlock(BlockPos pos, World world, float lookingYaw)
    {
        BlockPos pad = null;
        for(BlockPos warp : warps)
        {
            if (warp.getX() == pos.getX() && warp.getY() == pos.getY() && warp.getZ() == pos.getZ())
                continue;
                
            if (world.getBlockState(warp.add(0, 1, 0)) != Blocks.AIR.getDefaultState())
                continue;

            if (pad == null)
            {
                pad = warp;
                continue;
            }
            int manhattanA, manhattanB;
            manhattanA = warp.getManhattanDistance(pos);
            manhattanB = pad.getManhattanDistance(pos);
            if (manhattanA < manhattanB)
                pad = warp;
            else if (manhattanA == manhattanB)
            {
                //Get normalized vectors
            //     Vec3i toPad = pad.subtract(pos);
            //     Vec3i toWarp = warp.subtract(pos);

            //     Vec3d toPadF = new Vec3d(toPad.getX(), 0, toPad.getZ());
            //     toPadF.normalize();
            //     Vec3d toWarpF = new Vec3d(toWarp.getX(), 0, toWarp.getZ());
            //     toWarpF.normalize();
            //     Vec3d toForward = new Vec3d(Math.cos(lookingYaw), 0, Math.sin(lookingYaw));

            //     double cosSimPad = toForward.dotProduct(toPadF);
            //     double cosSimWarp = toForward.dotProduct(toWarpF);
            //     double angDistPad = Math.acos(cosSimPad) / Math.PI;
            //     double angDistWarp = Math.acos(cosSimWarp) / Math.PI;

            //     if ((1.0 - angDistPad) < (1.0 - angDistWarp))
            //         pad = warp;
            // }
                Vec3i vecA = warp.subtract(pos);
                Vec3i vecB = pad.subtract(pos);
                float warpDir = (float)Math.atan2(-(float)vecA.getX(), (float)vecA.getZ());
                float padDir = (float)Math.atan2(-(float)vecB.getX(), (float)vecB.getZ());
                if (warpDir < 0.f)
                    warpDir += Math.PI * 2.0;
                if (padDir < 0.f)
                    padDir += Math.PI * 2.0;
                if (lookingYaw < 0.f)
                    lookingYaw += 180.f;
                warpDir *= 180.0 / Math.PI;
                padDir *= 180.0 / Math.PI;

                // float warpAng = warpDir - lookingYaw;
                // float padAng = padDir - lookingYaw;

                // if (warpAng < 0.0)
                //     warpAng += 360.0;
                // else if (warpAng > 360.0)
                //     warpAng -= 360.0;

                // if (padAng < 0.0)
                //     padAng += 360.0;
                // else if (padAng > 360.0)
                //     padAng -= 360.0;
                
                if (Math.abs(warpDir - lookingYaw) < Math.abs(padDir - lookingYaw))
                    pad = warp;
            }
        }
        return pad;
    }
}