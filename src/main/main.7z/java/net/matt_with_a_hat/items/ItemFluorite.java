package net.matt_with_a_hat.items;

import net.minecraft.item.Item;

public class ItemFluorite extends Item
{
    public ItemFluorite(Settings settings)
    {
        super(settings);
    }
}